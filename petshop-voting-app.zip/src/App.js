export default function App() {
  return <div>Petshop Voting App (To be filled)</div>;
}